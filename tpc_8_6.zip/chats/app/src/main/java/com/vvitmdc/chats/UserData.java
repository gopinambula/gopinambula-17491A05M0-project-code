package com.vvitmdc.chats;

public class UserData {
    public static  String username="";
    public static  String chatWith="";
    public static String imageUrl="";
    public static boolean isStudent=false;

}
