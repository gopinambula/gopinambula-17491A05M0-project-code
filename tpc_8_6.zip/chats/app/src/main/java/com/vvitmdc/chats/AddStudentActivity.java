package com.vvitmdc.chats;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddStudentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);
        setTitle("Add Student");
    }
}
